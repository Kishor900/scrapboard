<footer>
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <span class="copyright">Copyright &copy; Scrapboard 2016</span>
            </div>
            <div class="col-md-4">
                <ul class="list-inline social-buttons">
                    <li><a href="https://twitter.com/scrapboard123" target="new"><i class="fa fa-twitter"></i></a>
                    </li>
                    <li><a href="https://www.facebook.com/scrapboard.co.in" target="new"><i class="fa fa-facebook"></i></a>
                    </li>
                    <li><a href="http://www.stumbleupon.com/stumbler/kishorparida7777" target="new"><i class="fa fa-stumbleupon"></i></a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</footer>
<!-- jQuery -->
<script src="<?php echo get_stylesheet_directory_uri() . "/js/jquery.js"; ?>"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo get_stylesheet_directory_uri() . "/js/bootstrap.min.js"; ?>"></script>

<!-- Plugin JavaScript -->
<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
<script src="<?php echo get_stylesheet_directory_uri() . "/js/classie.js"; ?>"></script>
<script src="<?php echo get_stylesheet_directory_uri() . "/js/cbpAnimatedHeader.js"; ?>"></script>

<!-- Contact Form JavaScript -->
<script src="<?php echo get_stylesheet_directory_uri() . "/js/jqBootstrapValidation.js"; ?>"></script>
<script src="<?php echo get_stylesheet_directory_uri() . "/js/contact_me.js"; ?>"></script>

<!-- Custom Theme JavaScript -->
<script src="<?php echo get_stylesheet_directory_uri() . "/js/agency.js"; ?>"></script>

</body>

</html>
<?php wp_footer(); ?>
